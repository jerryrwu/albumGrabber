from albumGrabberOOP import albumGetter
instance = albumGetter()
instance.start()